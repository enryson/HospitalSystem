<?php
//inicia a sessão
session_start();

?>
<!doctype html>
<html lang="pt-br">
<?php include("Components/Head.php"); ?>
<body>
<?php include("Components/Nav.php"); ?>
    
<div class="container">
    <div class="jumbotron">
<?php 
echo '<h1>Erro na pagina, contate o portal</h1>'
?>
</div>
</div>
</body>
<?php include("Components/Scripts.php"); ?>
</html>